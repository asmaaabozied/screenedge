@extends('layouts.dashboard.app')

@section('content')

    <div class="content-wrapper">

        <section class="content-header">

            <h1>@lang('site.settings')</h1>

            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard.welcome') }}"><i class="fa fa-dashboard"></i> @lang('site.dashboard')
                    </a></li>
                <li class="active">@lang('site.settings')</li>
            </ol>
        </section>

        <section class="content">

            <div class="box box-primary">

{{--                <div class="box-header with-border">--}}

{{--                    <h3 class="box-title" style="margin-bottom: 15px">@lang('site.customers')--}}
{{--                    </h3>--}}


{{--                </div><!-- end of box header -->--}}

                <div class="box-body table-responsive no-padding on-overflow-x minHeight">


                    <div class="box-body">
                        @include('partials._errors')
                        <div class="content">
                            <form action="{{ route('dashboard.settings.updateAll') }}" method="post">
{{--                                <hr style="border-color: #3c8dbcab"/>--}}
                                <div class="row">
                                @foreach($settings as $key=>$setting)
                                    {{ csrf_field() }}


                                    <div class="col-lg-6">

                                        <label style="margin: 5px">  {{$setting->name}} </label>
                                        <input class="form-control" value="{{$setting->value}}" name="{{$setting->name}}">

                                    </div>

                                @endforeach
                                </div>
                                <br>
                                <div class="form-group col-md-3">
                                    <button type="submit" class="btn btn-primary text-center"><i class="fa fa-edit"></i> @lang('site.edit')</button>
                                </div>
                            </form>


                            <br>





                        </div>


                    </div>


                </div>
            </div>
        </section>
    </div>

@endsection
