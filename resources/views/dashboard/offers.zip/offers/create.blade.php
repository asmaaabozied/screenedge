@extends('layouts.dashboard.app')

@section('content')

    <div class="content-wrapper">

        <section class="content-header">

            <h1>@lang('site.offers')</h1>

            <ol class="breadcrumb">
                <li><a href="{{ route('dashboard.welcome') }}"><i class="fa fa-dashboard"></i> @lang('site.dashboard')
                    </a>
                </li>
                <li><a href="{{ route('dashboard.offers.index') }}"> @lang('site.offers')</a></li>
                <li class="active">@lang('site.add')</li>
            </ol>
        </section>

        <section class="content">

            <div class="box box-primary">

                <div class="box-header">
                    <h3 class="box-title">@lang('site.add')</h3>
                </div><!-- end of box header -->

                <div class="box-body">

                    @include('partials._errors')

                    <form action="{{ route('dashboard.offers.store') }}" method="post" enctype="multipart/form-data">

                        {{ csrf_field() }}
                        {{ method_field('post') }}
                        <div class="row">

                            <div class="col-lg-6">


                                <label>@lang('site.start_at')</label>
                                <input type="date" name="start_at" class="form-control date"
                                       value="{{ old('start_at') }}">


                            </div>
                            <div class="col-lg-6">
                                <label>@lang('site.end_at')</label>
                                <input type="date" name="end_at" class="form-control date" value="{{ old('end_at') }}">


                            </div>

                        </div>

                        <div class="row">

                            <div class="col-lg-6">

                                <label>@lang('site.discount')</label>
                                <input type="number" name="discount" class="form-control" value="{{ old('discount') }}">


                            </div>
                            <div class="col-lg-6">
                                <label>@lang('site.halls')</label>
                                <select name="venue_id" class="form-control select2">
                                    <option value="">@lang('site.select')</option>
                                    @foreach ($halls as $key=>$hall)
                                        <option value="{{$key}}" {{ old('venue_id') == $key? 'selected' : '' }}>
                                            {{ $hall}}
                                        </option>
                                    @endforeach
                                </select>


                            </div>

                        </div>

<br>
                        <div class="form-group">
                            <button type="button" class="btn btn-warning mr-1"
                                    onclick="history.back();">
                                <i class="fa fa-backward"></i> @lang('site.back')
                            </button>
                            <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i>
                                @lang('site.add')</button>
                        </div>

                    </form><!-- end of form -->

                </div><!-- end of box body -->

            </div><!-- end of box -->

        </section><!-- end of content -->

    </div><!-- end of content wrapper -->

@endsection
