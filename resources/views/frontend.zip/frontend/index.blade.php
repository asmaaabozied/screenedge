@extends('frontend.master')
@section('content')
        <!-- Carousel Start -->
        <div id="carouselExampleControls slider" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="{{asset('frontend/images/home/slider-1.png')}}" class="d-block w-100" alt="slider">
                </div>
                @foreach($sliders as $key=>$slider)

                    <div class="carousel-item @if($loop->first) active @endif">

                        <img src="{{asset('uploads/'.$slider->image)}}" class="d-block w-100" alt="slider" style="max-height: 600px;">
                    </div>
                @endforeach
                            <div class="carousel-item">
                                <img src="{{asset('frontend/images/home/slider-1.png')}}" class="d-block w-100" alt="slider">
                            </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>

            <div class="slider__content">
                <h1 class="slider__title">Quick access to places near you</h1>
                <a href="#" class="slider__button">Reaching the places near you</a>
            </div>
        </div>
        <!-- Carousel End -->

        <!-- Services Start -->
        <div class="services">
            <div class="container">

                <div class="row">
                    @foreach($services as $service)
                        <div class="col-md-4">
                            <a href="#" class="card">
                                <img src="{{asset('uploads/'.$service->image)}}" class="card-img-top"
                                     alt="card image"/>
                                <div class="card-body">
                                    <h3 class="card-title">{{$service->name}} </h3>
                                    <p class="card-text">{{$service->description}} </p>
                                </div>
                            </a>
                        </div>
                    @endforeach
                </div>

            </div>
        </div>
        <!-- Services End -->

        <!-- Deal Start -->
        <div class="deal">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="deal__texts">
                            <h2 class="deal__title">Deal of the week</h2>
                            <h2 class="deal__titleAlt">Current offers for galleries</h2>
                            <ul class="deal__list">
                                <li class="deal__item">default text</li>
                                <li class="deal__item">default text</li>
                                <li class="deal__item">default text</li>
                                <li class="deal__item">default text</li>
                                <li class="deal__item">default text</li>
                                <li class="deal__item">default text</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img class="deal__image img-fluid" src="{{asset('frontend/images/home/deal-image.png')}}"
                             alt="deal image"/>
                    </div>
                </div>
            </div>
        </div>
        <!-- Deal End -->


@endsection
