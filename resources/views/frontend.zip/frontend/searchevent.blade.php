
@extends('frontend.master')
@section('content')


    <div class="reservform">
        <div class="container">
            <form class="reservform__form">
                <div class="reservform__content">
                    <input type="text" class="reservform__input reservform__inputSearch" placeholder="Where do you want to book ?">
                    <i class="fas fa-search reservform__icon"></i>
                </div>
                <div class="reservform__flex">
                    <div class="reservform__content reservform__flexContent">
                        <input type="date" class="reservform__input reservform__date" placeholder="Add time">
                    </div>
                    <div class="reservform__content reservform__flexContent">
                        <input type="text" class="reservform__input reservform__guest" placeholder="Add guests">
                        <i class="fas fa-users reservform__icon"></i>
                    </div>
                </div>
                <div class="reservform__flex">
                    <div class="reservform__content">
                        <i class="far fa-check-square reservform__orderIcon"></i>
                        <span class="reservform__orderTitle">Arrange from closest</span>
                    </div>
                    <div class="reservform__content">
                        <a href="#" class="reservform__search">Searches recently</a>
                    </div>
                </div>

                <div class="reservform__flex">
                    <div class="reservform__content reservform__flexContent">
                        <input type="submit" class="reservform__submit reservform__browse" value="Browse places">
                    </div>
                    <div class="reservform__content reservform__flexContent">
                        <input type="submit" class="reservform__submit reservform__search" value="Search">
                    </div>
                </div>
            </form>
            <div class="reservform__result">
                <div class="row">
                    @foreach($events as $event)
                    <div class="col-lg-6">
                        <div class="reservform__card">
                            <div class="reservform__cardImage">
                                <img src="{{asset('uploads/'.$event->image)}}" alt="image">
                            </div>
                            <div class="reservform__cardBody">
                                <h3 class="reservform__cardTitle">{{$event->name}}</h3>
                                <p class="reservform__cardPara">{{$event->description}}</p>
                            </div>
                        </div>
                    </div>

                    @endforeach

                </div>
            </div>

            <nav class="navigation-page" aria-label="Page navigation example">
                <ul class="pagination justify-content-center">
                    {{ $events->appends(request()->query())->links() }}

                </ul>
            </nav>

        </div>
    </div>




@endsection
