<?php

namespace App\Http\Controllers;

use App\Helpers\SocialiteHelper;


use Firebase\Auth\Token\Exception\InvalidToken;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Kreait\Laravel\Firebase\Facades\Firebase;

class VenuesController extends Controller
{

    public function index()
    {


    }



}
